package com.example.jun.test1;

import android.app.Application;

/**
 * Created by jun on 2017-10-29.
 */

public class App extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
