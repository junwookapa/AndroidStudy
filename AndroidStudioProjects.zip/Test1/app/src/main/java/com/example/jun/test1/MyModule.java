package com.example.jun.test1;

/**
 * Created by jun on 2017-10-29.
 */

public class MyModule {
    public static String getString(String str){
        return str+"1";
    }
}
